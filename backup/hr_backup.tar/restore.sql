--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 16.4 (Ubuntu 16.4-0ubuntu0.24.04.2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hr;
--
-- Name: hr; Type: DATABASE; Schema: -; Owner: hr
--

CREATE DATABASE hr WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE hr OWNER TO hr;

\connect hr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.countries (
    country_id character varying(2) NOT NULL,
    country_name character varying(40),
    region_id integer NOT NULL
);


ALTER TABLE public.countries OWNER TO hr;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(30),
    manager_id integer,
    location_id integer
);


ALTER TABLE public.departments OWNER TO hr;

--
-- Name: departments_department_id_seq; Type: SEQUENCE; Schema: public; Owner: hr
--

CREATE SEQUENCE public.departments_department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_department_id_seq OWNER TO hr;

--
-- Name: departments_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hr
--

ALTER SEQUENCE public.departments_department_id_seq OWNED BY public.departments.department_id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name character varying(20),
    last_name character varying(25) NOT NULL,
    email character varying(25) NOT NULL,
    phone_number character varying(20),
    job_id character varying(10),
    salary numeric(8,2),
    commission_pct numeric(2,2),
    manager_id integer,
    department_id integer
);


ALTER TABLE public.employees OWNER TO hr;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: hr
--

CREATE SEQUENCE public.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employee_id_seq OWNER TO hr;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hr
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO hr;

--
-- Name: job_history; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.job_history (
    employee_id integer,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    job_id character varying(10),
    department_id integer
);


ALTER TABLE public.job_history OWNER TO hr;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.jobs (
    job_id character varying(10) NOT NULL,
    job_title character varying(35),
    min_salary numeric(6,0),
    max_salary numeric(6,0)
);


ALTER TABLE public.jobs OWNER TO hr;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.locations (
    location_id integer NOT NULL,
    street_address character varying(40),
    postal_code character varying(12),
    city character varying(30),
    state_province character varying(25),
    country_id character varying(2)
);


ALTER TABLE public.locations OWNER TO hr;

--
-- Name: locations_location_id_seq; Type: SEQUENCE; Schema: public; Owner: hr
--

CREATE SEQUENCE public.locations_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_location_id_seq OWNER TO hr;

--
-- Name: locations_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hr
--

ALTER SEQUENCE public.locations_location_id_seq OWNED BY public.locations.location_id;


--
-- Name: mata_uang; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.mata_uang (
    id character varying(64) NOT NULL,
    nama character varying(100) NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    created_by character varying(100)
);


ALTER TABLE public.mata_uang OWNER TO hr;

--
-- Name: regions; Type: TABLE; Schema: public; Owner: hr
--

CREATE TABLE public.regions (
    region_id integer NOT NULL,
    region_name character varying(25)
);


ALTER TABLE public.regions OWNER TO hr;

--
-- Name: regions_region_id_seq; Type: SEQUENCE; Schema: public; Owner: hr
--

CREATE SEQUENCE public.regions_region_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_region_id_seq OWNER TO hr;

--
-- Name: regions_region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hr
--

ALTER SEQUENCE public.regions_region_id_seq OWNED BY public.regions.region_id;


--
-- Name: departments department_id; Type: DEFAULT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.departments ALTER COLUMN department_id SET DEFAULT nextval('public.departments_department_id_seq'::regclass);


--
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- Name: locations location_id; Type: DEFAULT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.locations ALTER COLUMN location_id SET DEFAULT nextval('public.locations_location_id_seq'::regclass);


--
-- Name: regions region_id; Type: DEFAULT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.regions ALTER COLUMN region_id SET DEFAULT nextval('public.regions_region_id_seq'::regclass);


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.countries (country_id, country_name, region_id) FROM stdin;
\.
COPY public.countries (country_id, country_name, region_id) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.departments (department_id, department_name, manager_id, location_id) FROM stdin;
\.
COPY public.departments (department_id, department_name, manager_id, location_id) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.employees (employee_id, first_name, last_name, email, phone_number, job_id, salary, commission_pct, manager_id, department_id) FROM stdin;
\.
COPY public.employees (employee_id, first_name, last_name, email, phone_number, job_id, salary, commission_pct, manager_id, department_id) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.
COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: job_history; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.job_history (employee_id, start_date, end_date, job_id, department_id) FROM stdin;
\.
COPY public.job_history (employee_id, start_date, end_date, job_id, department_id) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.jobs (job_id, job_title, min_salary, max_salary) FROM stdin;
\.
COPY public.jobs (job_id, job_title, min_salary, max_salary) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.locations (location_id, street_address, postal_code, city, state_province, country_id) FROM stdin;
\.
COPY public.locations (location_id, street_address, postal_code, city, state_province, country_id) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: mata_uang; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.mata_uang (id, nama, last_updated, created_by) FROM stdin;
\.
COPY public.mata_uang (id, nama, last_updated, created_by) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: hr
--

COPY public.regions (region_id, region_name) FROM stdin;
\.
COPY public.regions (region_id, region_name) FROM '$$PATH$$/3378.dat';

--
-- Name: departments_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hr
--

SELECT pg_catalog.setval('public.departments_department_id_seq', 1, false);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hr
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 1, false);


--
-- Name: locations_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hr
--

SELECT pg_catalog.setval('public.locations_location_id_seq', 1, false);


--
-- Name: regions_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hr
--

SELECT pg_catalog.setval('public.regions_region_id_seq', 1, false);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (country_id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (job_id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (location_id);


--
-- Name: mata_uang mata_uang_nama_key; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.mata_uang
    ADD CONSTRAINT mata_uang_nama_key UNIQUE (nama);


--
-- Name: mata_uang mata_uang_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.mata_uang
    ADD CONSTRAINT mata_uang_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (region_id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: hr
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: countries fk_contries_region_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT fk_contries_region_id FOREIGN KEY (region_id) REFERENCES public.regions(region_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: departments fk_departments_location_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_location_id FOREIGN KEY (location_id) REFERENCES public.locations(location_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: departments fk_departments_manager_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_manager_id FOREIGN KEY (manager_id) REFERENCES public.employees(employee_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees fk_employees_department_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_department_id FOREIGN KEY (department_id) REFERENCES public.departments(department_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees fk_employees_job_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_job_id FOREIGN KEY (job_id) REFERENCES public.jobs(job_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees fk_employees_manager_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_manager_id FOREIGN KEY (manager_id) REFERENCES public.employees(employee_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: job_history fk_job_history_department_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.job_history
    ADD CONSTRAINT fk_job_history_department_id FOREIGN KEY (department_id) REFERENCES public.departments(department_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: job_history fk_job_history_job_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.job_history
    ADD CONSTRAINT fk_job_history_job_id FOREIGN KEY (job_id) REFERENCES public.jobs(job_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: locations fk_locations_contry_id; Type: FK CONSTRAINT; Schema: public; Owner: hr
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT fk_locations_contry_id FOREIGN KEY (country_id) REFERENCES public.countries(country_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

